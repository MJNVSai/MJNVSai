from django import forms
from MJNVSAI.models import student

class Login(forms.ModelForm):
    class Meta:
        model = student
        fields = '__all__'