from django.shortcuts import render,redirect
from django.http import HttpResponse
from MJNVSAI.forms import Login
from .models import student
# Create your views here.

# objects = Login()
#     if request.method == 'POST':
#         objects = Login(request.POST)
#     if objects.is_valid():
#         objects.save(commit=True)
#     return render(request, 'Index.html', {'objects' : objects})

def student_list(request):
    context = {'student_list': student.objects.all()}
    return render(request,"student_list.html",context)


def student_form(request,id = 0):
    if request.method ==  "GET":
        if id == 0:
            form = Login()
        else:
            Sdent = student.objects.get(pk = id) # pk = primary key
            form = Login(instance = Sdent)
        return render(request,"student_form.html",{'form':form})
    else:
        if id == 0:
            form = Login(request.POST)
        else:
            Sdent = student.objects.get(pk=id)  # pk = primary key
            form = Login(request.POST, instance = Sdent)
        if form.is_valid():
            form.save()
        return redirect('/form')

def student_delete(request,id):
    Sdent = student.objects.get(pk=id)  # pk = primary key
    Sdent.delete()

    return redirect('/form')
