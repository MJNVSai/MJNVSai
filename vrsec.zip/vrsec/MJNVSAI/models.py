from django.db import models
# from django.forms.widgets import RadioSelect
# form django import forms
# from django.db import forms

# Create your models here.
Department = [
    ('cse','CSE'),
    ('it','IT'),
    ('ece','ECE'),
    ('eee','EEE'),
    ('eie','EIE'),
    ('mechanical','MECHANICAL'),
    ('civil','CIVIL'),
]

gen = (
    ('choose','CHOOSE'),
    ('male','MALE'),
    ('female','FEMALE'),
    ('others','OTHERS'),
)
class student(models.Model):
    name = models.CharField(max_length=100)
    branch = models.CharField(max_length=100)
    number = models.CharField(max_length=100)
    mail = models.EmailField(default = "xyz@gmail.com")
    mobile = models.IntegerField(default = "1234567892")
    dept = models.CharField(max_length = 12,choices = Department, default = 'it')
    playing = models.BooleanField(" PLAYING ",default = False)
    studying = models.BooleanField(" STUDYING ",default = False)
    editing = models.BooleanField(" Video and Photo Editing ",default = False)
    Gender = models.CharField(max_length=12, choices=gen, default="CHOOSE")
    address = models.TextField(default = "please fill this field")